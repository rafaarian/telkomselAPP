-> node-android folder contains the server part.
-> NodeLogin folder contains the Android Source Code

-> Use the IP 10.0.2.2 when running from Android Emulator. 
-> Use the IP 192.168.56.1 when running the project fom Genymotion.

-> In chgpass.js use you own email and password for SMTP mail to reset Password.

Reference URL in Learn2Crack

 
Server -> http://www.learn2crack.com/2014/04/android-login-registration-nodejs-server.html

Client -> http://www.learn2crack.com/2014/04/android-login-registration-nodejs-client.html


For any queries comment on the respective pages in our website.
